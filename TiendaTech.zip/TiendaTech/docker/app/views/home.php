<?php /* home.php */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../models/ProductoModel.php';
require_once __DIR__ . '/../models/DetalleVentaModel.php';

$sqlMasVendidos = getBaseDetalleVentaSQL();
$stidMasVendidos = oci_parse($conn, $sqlMasVendidos);
oci_execute($stidMasVendidos);

$sql = getBaseProductosSQL() . " ORDER BY p.NOMBRE";
$stid = oci_parse($conn, $sql);
oci_execute($stid);
?>

<!-- =========================
     TOP MÁS VENDIDOS
========================= -->
<div class="sub-container">
    <h1 class="titulo-seccion">🔥 Top 6 más vendidos</h1>

    <div class="top-grid">
        <?php while ($row = oci_fetch_assoc($stidMasVendidos)) { ?>
            <?php include __DIR__ . '/components/info_producto.php'; ?>
        <?php } ?>
    </div>
</div>

<!-- =========================
     PRODUCTOS DISPONIBLES
========================= -->
<div class="main-container">
    <h1 class="titulo-seccion">Productos disponibles</h1>

    <div class="productos-grid">
        <?php while ($row = oci_fetch_assoc($stid)) { ?>
            <?php include __DIR__ . '/components/info_producto.php'; ?>
        <?php } ?>
    </div>
</div>