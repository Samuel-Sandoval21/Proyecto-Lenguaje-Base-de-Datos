-- =========================
-- CATEGORIAS
-- =========================
INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Teclados', 'Perifericos');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Mouses', 'Perifericos');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Microfonos', 'Perifericos');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Headsets', 'Perifericos');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Controles', 'Perifericos');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Mouse Pads', 'Perifericos');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Memoria RAM', 'Componentes');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Almacenamiento', 'Componentes');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Graficas', 'Componentes');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Refrigeraciones', 'Componentes');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Ventilacion', 'Componentes');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Televisores', 'Para el Hogar');

INSERT INTO CATEGORIAS (NOMBRE_CATEGORIA, TIPO_GENERAL) VALUES ('Routers', 'Para el Hogar');

COMMIT;
SELECT * FROM CATEGORIAS;

-- =========================
-- MARCAS
-- =========================
INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Razer');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Samsung');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Logitech');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Kingston');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('HyperX');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('HP');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Huawei');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Wacom');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('XP Pen');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('AOC');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Acer');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Intel');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('AMD');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Nvidia');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Aerocool');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('ThermalTake');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Antec');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Corsair');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Noctua');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Cooler Master');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('NZXT');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Lian LI');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Red Dragon');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Adata');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('G.SKILL');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Xiaomi');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('MSI');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Asus');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Gigabyte');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('LG');

INSERT INTO MARCAS (NOMBRE_MARCA) VALUES ('Aorus');

-- =========================
-- PRODUCTOS
-- =========================
-- =========================
-- PERIFERICOS
-- =========================
SET DEFINE OFF;
INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (1, 1, 'Razer BlackWidow V4', 'Teclado mecanico RGB', 150, 15, 'https://www.techzilla.cr/wp-content/uploads/2024/02/1-22.jpg.webp');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (2, 3, 'Logitech G502', 'Mouse gamer alta precision', 80, 25, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDJQfsyLJjNpjHmgYCKX9CbwaeBW_3WnaY8A&s');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (3, 5, 'HyperX SoloCast', 'Microfono USB condensador', 65, 18, 'https://www.cqnetcr.com/114105-thickbox_default/microfono-hyperx-solocast-usb-led-cardioide.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (4, 1, 'Razer Kraken X', 'Headset gamer 7.1', 90, 20, 'https://m.media-amazon.com/images/I/51EafLX7lRL._AC_UF894,1000_QL80_.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (5, 3, 'Logitech F310', 'Control USB para PC', 40, 30, 'https://holacompras.com/wp-content/uploads/2024/09/940-000110-2.png');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (6, 23, 'Red Dragon Flick', 'Mouse Pad XL', 20, 40, 'https://www.techzilla.cr/wp-content/uploads/2024/02/redragon-flick-3xl-p040.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (1, 3, 'Logitech G Pro X', 'Teclado mecanico profesional', 140, 12, 'https://www.techzilla.cr/wp-content/uploads/2025/01/Sin-titulo-1-162.jpg.webp');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (1, 28, 'Asus TUF K3', 'Teclado mecanico RGB resistente', 110, 16, 'https://m.media-amazon.com/images/I/51lcg2odrdL._AC_SL1000_.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (1, 29, 'Gigabyte K1', 'Teclado mecanico gamer', 95, 20, 'https://www.cqnetcr.com/114736-large_default/teclado-mecanico-gigabyte-aorus-k1-usb-usb-rgb.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (2, 1, 'Razer DeathAdder V3', 'Mouse gamer ergonomico', 85, 22, 'https://www.techzilla.cr/wp-content/uploads/2023/07/MO2118-4.jpg.webp');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (2, 27, 'MSI Clutch GM41', 'Mouse ligero 16000 DPI', 70, 18, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqH33uKN1EXfGkKhDrvbI6DdcEaJ5XOJ0bXg&s');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (2, 30, 'LG Silent Mouse', 'Mouse inalambrico silencioso', 25, 40, 'https://www.intelec.co.cr/wp-content/uploads/2024/11/910-007116-1000x1000.webp');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (3, 5, 'HyperX QuadCast', 'Microfono RGB profesional', 130, 14, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVcU4kzETFxPYjbi7EcJRdtyd81m6re8puMg&s');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (3, 6, 'HP Streaming Mic', 'Microfono USB compacto', 55, 19, 'https://hp.widen.net/content/lizgrksgs4/webp/lizgrksgs4.png?dpi=72&color=ffffff00&w=270');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (4, 23, 'Red Dragon Zeus X', 'Headset gamer 7.1 RGB', 75, 21, 'https://extremetechcr.com/wp-content/uploads/2024/11/37890.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (4, 1, 'Razer Barracuda X', 'Headset inalambrico', 120, 13, 'https://m.media-amazon.com/images/I/71qKH+vJ+IL._AC_SL1500_.jpg');


-- =========================
-- COMPONENTES
-- =========================
INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (7, 4, 'Kingston Fury 16GB', 'RAM DDR4 16GB 3200MHz', 75, 35, 'https://www.intelec.co.cr/wp-content/uploads/2024/11/910-005469.webp');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (7, 18, 'Corsair Vengeance 16GB', 'RAM DDR4 16GB 3200MHz', 75, 30, 'https://coretms.tecnomegastore.ec/assets/images/main/26/DIMCORH325MB638.webp');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (7, 4, 'Kingston Fury Beast 16GB', 'RAM DDR5 16GB 5200MHz', 95, 25, 'https://media.kingston.com/kingston/product/FURY_Beast_Black_DDR4_1_pkg-zm-lg.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (7, 25, 'G.SKILL Trident Z 32GB', 'RAM DDR4 32GB 3600MHz', 160, 15, 'https://cyberteamcr.com/wp-content/uploads/2025/10/20588_18063.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (7, 5, 'HyperX Fury 8GB', 'RAM DDR4 8GB 3200MHz', 40, 45, 'https://gabastorecr.com/wp-content/uploads/2023/04/CP-HYPERX-HX430C15FB38-3.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (8, 4, 'Kingston NV2 500GB', 'SSD NVMe 500GB', 60, 30, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzArqEmGk7l-FX2zNvSuik-iiZWMxme6GA4w&s');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (8, 2, 'Samsung 980 Pro 2TB', 'SSD NVMe Gen4 2TB', 210, 9, 'https://m.media-amazon.com/images/I/81mJYmdViYL._SY250_.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (8, 24, 'Adata Legend 1TB', 'SSD NVMe 1TB', 110, 22, 'https://www.intelec.co.cr/wp-content/uploads/2025/01/SLEG-860-1000GCS.png');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (8, 24, 'Adata SU650 480GB', 'SSD SATA 480GB', 50, 28, 'https://webapi3.adata.com/storage/product/23_p_su650_04_0628.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (9, 13, 'AMD RX 7600', 'Tarjeta grafica 8GB GDDR6', 350, 11, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_1Fyq8_ShJhNWj4NQbgNEnfrFn6iEps0U1w&s');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (9, 14, 'Nvidia RTX 4060', 'Tarjeta grafica 8GB GDDR6', 400, 12, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpC6en7rI64nIKGcO5IZroW88IMvxruwHqrg&s');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (9, 27, 'MSI RTX 4070', 'Tarjeta grafica 12GB', 650, 7, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsgtRmSlEkEXOzxNRFkUdw4VbXPlT18b0rJA&s');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (9, 29, 'Gigabyte RTX 4090', 'Tarjeta grafica 24GB GDDR6X', 1600, 3, 'https://images-na.ssl-images-amazon.com/images/I/71TZmq7RYtL._AC_UL495_SR435,495_.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (10, 16, 'ThermalTake Water 3.0', 'Refrigeracion liquida 240mm', 130, 10, 'https://cdn11.bigcommerce.com/s-p52by1ef7/images/stencil/1280x1280/products/89232/89470/CA-007PL12__06771__83353.1550182145.JPG?c=2');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (10, 20, 'Cooler Master ML240L', 'Refrigeracion liquida RGB', 125, 12, 'https://m.media-amazon.com/images/I/61g3UkYPnmL._SL1500_.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (10, 18, 'Corsair H100i', 'Watercooling 240mm', 150, 8, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0NqZzCtq-hshsB9yu_U3g2nFkz6vboY4Hvg&s');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (11, 21, 'NZXT F120 RGB', 'Ventilador RGB 120mm', 30, 35, 'https://m.media-amazon.com/images/I/51dYwbuFI1L._SL1000_.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (11, 19, 'Noctua NF-A12x25', 'Ventilador 120mm silencioso', 35, 50, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzSH8VG2xxvbtjy8-i_6Mxj774CY3uZPlkNA&s');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (11, 17, 'Antec Prizm 120', 'Ventilador alto flujo', 28, 42, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqSOaXrpgcNUW1I8b_Ldt5_Pzpn1IYpbgAfQ&s');

-- =========================
-- HOGAR
-- =========================
INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (12, 31, 'Aorus OLED 48"', 'TV OLED 4K 120Hz', 900, 5, 'https://m.media-amazon.com/images/I/71xAK1yIIwL._AC_UF894,1000_QL80_.jpg');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (12, 2, 'Samsung Crystal 50"', 'Smart TV 4K UHD', 500, 10, 'https://me-tiendamexpress.s3.us-east-1.amazonaws.com/images/thumbs/0064255_pantalla-samsung-50-un50du7000pxpa-smart-tv-4k_600.png');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (13, 26, 'Xiaomi Mi Router AX1800', 'Router WiFi 6 Dual Band', 85, 18, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4Jgdbdze_4TS6ihdqRT_EI-YZLYbJ09LsaA&s');

INSERT INTO PRODUCTOS (ID_CATEGORIA, ID_MARCA, NOMBRE, DESCRIPCION, PRECIO, STOCK, IMAGEN) VALUES (13, 7, 'Huawei WiFi Mesh 7', 'Sistema Mesh WiFi', 180, 6, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQveSkVJGYbhXRj584YiwgGc4IrAvpihYwFQA&s');
SET DEFINE ON;
COMMIT;

SELECT * FROM PRODUCTOS;
-- =========================
-- METODOS_PAGO
-- =========================
INSERT INTO METODOS_PAGO (NOMBRE) VALUES ('Efectivo');

INSERT INTO METODOS_PAGO (NOMBRE) VALUES ('Tarjeta');

INSERT INTO METODOS_PAGO (NOMBRE) VALUES ('Transferencia');
COMMIT;

-- =========================
-- CLIENTES
-- =========================
INSERT INTO CLIENTES (NOMBRE, APELLIDO) VALUES ('Juan', 'Perez');

INSERT INTO CLIENTES (NOMBRE, APELLIDO) VALUES ('Maria', 'Lopez');

INSERT INTO CLIENTES (NOMBRE, APELLIDO) VALUES ('Carlos', 'Ramirez');

INSERT INTO CLIENTES (NOMBRE, APELLIDO) VALUES ('Ana', 'Gomez');
COMMIT;

-- =========================
-- USUARIOS
-- ========================
INSERT INTO USUARIOS (USERNAME, PASSWORD, ROL) VALUES ('admin', 'admin123', 'ADMIN');

INSERT INTO USUARIOS (USERNAME, PASSWORD, ROL) VALUES ('vendedor1', 'vend123', 'VENDEDOR');

INSERT INTO USUARIOS (USERNAME, PASSWORD, ROL, ID_CLIENTE) VALUES ('juanp', '1234', 'CLIENTE', 1);

INSERT INTO USUARIOS (USERNAME, PASSWORD, ROL, ID_CLIENTE) VALUES ('marial', '1234', 'CLIENTE', 2);
COMMIT;

-- =========================
-- PROVEEDORES
-- =========================
INSERT INTO PROVEEDORES (NOMBRE, CORREO) VALUES ('Distribuidora Tech', 'ventas@distech.com');

INSERT INTO PROVEEDORES (NOMBRE, CORREO) VALUES ('Importadora Digital', 'contacto@impodigital.com');

INSERT INTO PROVEEDORES (NOMBRE, CORREO) VALUES ('CompuMayorista', 'info@compumayorista.com');
COMMIT;

-- =========================
-- TELEFONOS CLIENTES
-- =========================
INSERT INTO TELEFONOS (ID_CLIENTE, TELEFONO) VALUES (1, '70001234');

INSERT INTO TELEFONOS (ID_CLIENTE, TELEFONO) VALUES (2, '71112222');

INSERT INTO TELEFONOS (ID_CLIENTE, TELEFONO) VALUES (3, '72223333');

INSERT INTO TELEFONOS (ID_CLIENTE, TELEFONO) VALUES (4, '73334444');
COMMIT;

-- =========================
-- CORREOS CLIENTES
-- =========================
INSERT INTO CORREOS (ID_CLIENTE, CORREO) VALUES (1, 'juan@gmail.com');

INSERT INTO CORREOS (ID_CLIENTE, CORREO) VALUES (2, 'maria@gmail.com');

INSERT INTO CORREOS (ID_CLIENTE, CORREO) VALUES (3, 'carlos@gmail.com');

INSERT INTO CORREOS (ID_CLIENTE, CORREO) VALUES (4, 'ana@gmail.com');
COMMIT;

-- =========================
-- DIRECCIONES
-- =========================
INSERT INTO DIRECCIONES (ID_CLIENTE, DIRECCION) VALUES (1, 'Av Siempre Viva 123');

INSERT INTO DIRECCIONES (ID_CLIENTE, DIRECCION) VALUES (2, 'Calle Central 456');

INSERT INTO DIRECCIONES (ID_CLIENTE, DIRECCION) VALUES (3, 'Zona Norte 789');

INSERT INTO DIRECCIONES (ID_CLIENTE, DIRECCION) VALUES (4, 'Boulevard Principal 321');
COMMIT;

-- =========================
-- TELEFONOS PROVEEDOR
-- =========================
INSERT INTO TELEFONOS_PROVEEDOR (ID_PROVEEDOR, TELEFONO) VALUES (1, '80001111');

INSERT INTO TELEFONOS_PROVEEDOR (ID_PROVEEDOR, TELEFONO) VALUES (2, '80002222');

INSERT INTO TELEFONOS_PROVEEDOR (ID_PROVEEDOR, TELEFONO) VALUES (3, '80003333');
COMMIT;



-- =========================
-- VENTAS
-- =========================
INSERT INTO VENTAS (ID_CLIENTE, ID_METODO, TOTAL) VALUES (1, 2, 230);

INSERT INTO VENTAS (ID_CLIENTE, ID_METODO, TOTAL) VALUES (2, 1, 90);

INSERT INTO VENTAS (ID_CLIENTE, ID_METODO, TOTAL) VALUES (3, 3, 160);
COMMIT;

-- =========================
-- PRODUCTO_ATRIBUTOS
-- =========================
INSERT INTO PRODUCTO_ATRIBUTOS (ID_PRODUCTO, NOMBRE_ATRIBUTO, VALOR) VALUES (1, 'Tipo Switch', 'Green');

INSERT INTO PRODUCTO_ATRIBUTOS (ID_PRODUCTO, NOMBRE_ATRIBUTO, VALOR) VALUES (1, 'RGB', 'Si');

INSERT INTO PRODUCTO_ATRIBUTOS (ID_PRODUCTO, NOMBRE_ATRIBUTO, VALOR) VALUES (17, 'Capacidad', '16GB');

INSERT INTO PRODUCTO_ATRIBUTOS (ID_PRODUCTO, NOMBRE_ATRIBUTO, VALOR) VALUES (17, 'Frecuencia', '3200MHz');

INSERT INTO PRODUCTO_ATRIBUTOS (ID_PRODUCTO, NOMBRE_ATRIBUTO, VALOR) VALUES (21, 'Capacidad', '2TB');
COMMIT;


-- =========================
-- DETALLE_VENTA
-- =========================
INSERT INTO DETALLE_VENTA (ID_VENTA, ID_PRODUCTO, CANTIDAD, PRECIO_UNITARIO) VALUES (1, 1, 1, 150);

INSERT INTO DETALLE_VENTA (ID_VENTA, ID_PRODUCTO, CANTIDAD, PRECIO_UNITARIO) VALUES (1, 2, 1, 80);

INSERT INTO DETALLE_VENTA (ID_VENTA, ID_PRODUCTO, CANTIDAD, PRECIO_UNITARIO) VALUES (2, 4, 1, 90);
COMMIT;
